package com.example.UserDBSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserDbSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserDbSecurityApplication.class, args);
	}

}
